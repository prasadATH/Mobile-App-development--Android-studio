package com.example.tic_tac_toe;

public class Avatar {

    int avatarImage;

    public Avatar(int avatarImage){
        this.avatarImage = avatarImage;
    }

}
